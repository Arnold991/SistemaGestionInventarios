package inventario;

public class Proveedor extends Entidad {

    public Proveedor(String nombre) {
        super(nombre);
    }

    @Override
    public String descripcion() {
        return "Proveedor: " + nombre;
    }
}
