package inventario;

public class Producto {
    private String codigo;
    private String nombre;
    private int cantidad;
    private double precio;
    private Categoria categoria;
    private Proveedor proveedor;

    public Producto(String codigo, String nombre, int cantidad, double precio, Categoria categoria, Proveedor proveedor) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
        this.categoria = categoria;
        this.proveedor = proveedor;
    }

    public String getCodigo() {
        return codigo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public String getNombre() {
        return nombre;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public boolean stockBajo() {
        return cantidad < 5;
    }

    @Override
    public String toString() {
        return "Código: " + codigo + ", Nombre: " + nombre + ", Cantidad: " + cantidad +
               ", Precio: L." + precio + ", " + categoria.descripcion() + ", " + proveedor.descripcion();
    }
}

