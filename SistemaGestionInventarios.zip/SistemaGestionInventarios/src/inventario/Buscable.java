package inventario;

public interface Buscable {
    Producto buscarProducto(String codigo);
}
