package inventario;

import java.util.ArrayList;

public class Inventario implements Buscable {
    private ArrayList<Producto> productos;

    public Inventario() {
        productos = new ArrayList<>();
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public void mostrarInventario() {
        if (productos.isEmpty()) {
            System.out.println("El inventario está vacío.");
        } else {
            for (Producto p : productos) {
                System.out.println(p);
                if (p.stockBajo()) {
                    System.out.println("⚠️ ALERTA: Stock bajo para el producto " + p.getNombre());
                }
            }
        }
    }

    @Override
    public Producto buscarProducto(String codigo) {
        for (Producto p : productos) {
            if (p.getCodigo().equalsIgnoreCase(codigo)) {
                return p;
            }
        }
        return null;
    }
}
