package inventario;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Inventario inventario = new Inventario();
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n===== MENÚ DEL SISTEMA =====");
            System.out.println("1. Agregar producto");
            System.out.println("2. Mostrar inventario");
            System.out.println("3. Buscar producto");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(sc.nextLine());

                switch (opcion) {
                    case 1:
                        System.out.print("Código: ");
                        String codigo = sc.nextLine();
                        System.out.print("Nombre: ");
                        String nombre = sc.nextLine();
                        System.out.print("Cantidad: ");
                        int cantidad = Integer.parseInt(sc.nextLine());
                        System.out.print("Precio: ");
                        double precio = Double.parseDouble(sc.nextLine());
                        System.out.print("Categoría: ");
                        String cat = sc.nextLine();
                        System.out.print("Proveedor: ");
                        String prov = sc.nextLine();

                        Categoria categoria = new Categoria(cat);
                        Proveedor proveedor = new Proveedor(prov);

                        Producto producto = new Producto(codigo, nombre, cantidad, precio, categoria, proveedor);
                        inventario.agregarProducto(producto);
                        System.out.println("✅ Producto agregado correctamente.");
                        break;

                    case 2:
                        inventario.mostrarInventario();
                        break;

                    case 3:
                        System.out.print("Ingrese el código del producto: ");
                        String codBuscar = sc.nextLine();
                        Producto encontrado = inventario.buscarProducto(codBuscar);
                        if (encontrado != null) {
                            System.out.println("✅ Producto encontrado:\n" + encontrado);
                        } else {
                            System.out.println("❌ Producto no encontrado.");
                        }
                        break;

                    case 4:
                        System.out.println("👋 Saliendo del sistema...");
                        break;

                    default:
                        System.out.println("❗ Opción no válida.");
                }

            } catch (NumberFormatException e) {
                System.out.println("❗ Error: entrada inválida. Intente de nuevo.");
                opcion = 0; // reinicia para que vuelva al menú
            }

        } while (opcion != 4);

        sc.close();
    }
}
