package inventario;

public class Categoria extends Entidad {

    public Categoria(String nombre) {
        super(nombre);
    }

    @Override
    public String descripcion() {
        return "Categoría: " + nombre;
    }
}
